import 'dart:ui';

import 'hex_color.dart';

final cPrimaryColor = HexColor('727C8E');
final cOmarColor = HexColor('4C4C4C');
final cHintColor = HexColor('C4AEA3');
final cBlack = HexColor('000000');
final cLightRed = HexColor('EC4117');
final cText = HexColor('404040');
final cWhite = HexColor('FFFFFF');
final cLiteBlue = HexColor('1B97D44D');
final cDarkGrey = HexColor('707070');
final cLightGrey = HexColor('BFBFBF');
final cLightYellow = HexColor('C9942F');
final cLightLemon =  HexColor('FFCC30');
final cGreyWithOpacity= Color(0xff1B97D4).withOpacity(0.10);
final cKey =  "OmAR79CG3D827DAlI122WRFfcDS3112";

